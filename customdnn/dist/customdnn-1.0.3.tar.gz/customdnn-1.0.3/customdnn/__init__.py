# -*- coding: utf-8 -*-
"""
Created on Mon April 13 10:57:42 2020

@author: singhmnprt01@gmail.com

customdnn Copyright (C) 2020 singhmnprt01@gmail.com
"""


from customdnn import network_train
from customdnn import network_predict

__all__=('network_train')
__all__=('network_predict')