# Authors: Manpreet Singh <singhmnprt01@gmail.com>
# customdnn Copyright (C) 2020 singhmnprt01@gmail.com
# License: GNU GENERAL PUBLIC LICENSE


from customdnn import network_train
from customdnn import network_predict

__all__ = ('network_train')
__all__ = ('network_predict')
